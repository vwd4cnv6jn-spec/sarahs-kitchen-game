# لعبة Sarah's Kitchen — جاهزة للنشر على GitHub Pages

## طريقة الرفع
1. افتحي GitHub وأنشئي Repository جديدًا باسم `sarahs-kitchen-game`.
2. اجعليه Public.
3. من المستودع اختاري Add file ثم Upload files.
4. ارفعي ملف `index.html` الموجود داخل هذا المجلد (لا تغيّري اسمه).
5. اضغطي Commit changes.
6. افتحي Settings ثم Pages.
7. تحت Build and deployment اختاري:
   - Source: Deploy from a branch
   - Branch: main
   - Folder: /(root)
8. اضغطي Save وانتظري بضع دقائق.
9. سيظهر رابط اللعبة في صفحة Pages، ويكون عادةً:
   https://YOUR-USERNAME.github.io/sarahs-kitchen-game/

استبدلي YOUR-USERNAME باسم حسابك في GitHub. لا يمكن إنشاء الرابط العام قبل رفع الملف إلى حسابك.
